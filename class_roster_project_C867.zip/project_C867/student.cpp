#pragma once
#include "student.h"

Student::Student(string sID, string fName, string lName, string sEmail, int sAge, int* compDays, DegreeProgram degProgram) {                                // Default Constructor
	studentID = sID;                            // Default Student ID 
	firstName = fName;                          // Default First Name 
	lastName = lName;                           // Default Last Name
	studentEmail = sEmail;						// Default Email Address
	age = sAge;                                 // Default Age
	for (int i = 0; i < numDays; i++) {
		numCompletionDays[i] = compDays[i];
	}
	program = degProgram;
}

void Student::SetStudentID(string newStudentID) {
	studentID = newStudentID; //Set new StudentID
}

void Student::SetFirstName(string newFirstName) {
	firstName = newFirstName; //Set new first name
}

void Student::SetLastName(string newLastName) {
	lastName = newLastName; //Set new last name
}

void Student::SetEmail(string newEmail) {
	studentEmail = newEmail; //Set new email
}

void Student::SetAge(int newAge) {
	age = newAge; //Set new age
}

void Student::SetNumCompletionDays(int* beginCompletionDays) {
	for (int i = 0; i < 3; i++) { 
		numCompletionDays[i] = beginCompletionDays[i]; //Set beginning days to completions for 3 courses
	}
}

void Student::SetProgram(DegreeProgram newDegreeProgram) { 
	program = newDegreeProgram; //Set new Degree Program
	}

string Student::GetStudentID() {
	return studentID;
}

string Student::GetFirstName() {
	return firstName;
}

string Student::GetLastName() {
	return lastName;
}

string Student::GetEmail() {
	return studentEmail;
}

int Student::GetAge() {
	return age;
}

int* Student::GetNumCompletionDays() {
	return numCompletionDays;
}

DegreeProgram Student::GetProgram() {
	return program;
}

void Student::PrintHeader() { // Header added for clarity when printing student or Roster
	cout << "StudentID|FirstName|LastName|Email|Age|DaysLeftinCourses|DegreeProgram\n";
}

void Student::PrintStudent() {
	cout << GetStudentID() << '\t';
	cout << "First Name: " << GetFirstName() << '\t';
	cout << "Last Name: " << GetLastName() << '\t';
	cout << "Email Address: " << GetEmail() << '\t';
	cout << "Age: " << GetAge() << '\t';
	cout << "Number of days to complete each course: "; 
	cout << GetNumCompletionDays()[0] << ", ";
	cout << GetNumCompletionDays()[1] << ", ";
	cout << GetNumCompletionDays()[2] << '\t'; //would use loop here but same time and space with only 3 options
	cout << "Degree Program: " << programStrings[GetProgram()] << endl;
}