#include "roster.h"
#include <iostream>

//this function is called in parse function, creating classRosterArray of 5 Student objects
void Roster::add(string sID, string fName, string lName, string dEmail, int dAge, int days1, int days2, int days3, DegreeProgram degProgram) {
	int days[3] = {days1, days2, days3}; //puts completion days back into array for constructor
	classRosterArray[++lastIndex] = new Student(sID, fName, lName, dEmail, dAge, days, degProgram);
}

void Roster::removeStudent(string studentID) {
	bool notFound = true; //it's never aliens...(i.e., assume it's false)
	for (int i = 0; i <= Roster::lastIndex; i++) {

		if (classRosterArray[i]->GetStudentID() == studentID) {
			notFound = false; //until it is

			if (i < numStudents - 1) {
				Student* swapHold = classRosterArray[i]; //Store to push_back to lastIndex (vectors? do you even c++ bro?)
				classRosterArray[i] = classRosterArray[lastIndex]; //Swap in lastIndex to index i
				classRosterArray[lastIndex] = swapHold; //Cumbersome array push_back complete
			}
			Roster::lastIndex--; //Cumbersome array.pop work around. *Makes value invisible by decrementing lastIndex by 1*
			cout << "Student: " << studentID << " successfully removed." << endl;
			break; //You need one after all that
		}
	} if (notFound) { //Too bad, you came all this way and didn't find what you were looking for
		cout << "Student: " << studentID << " not found." << endl;
	}
}
//Prints all students on class roster
void Roster::printAll() {
	classRosterArray[0]->PrintHeader(); //Prints Header
	for (int i = 0; i < (Roster::lastIndex + 1); i++) {
		classRosterArray[i]->PrintStudent(); //Prints all students using print function
	}
}
//Loop through cRA for StudentID match, loop through numCompDays and compute average
void Roster::printAverageDaysInCourse(string StudentID) {
	for (int i = 0; i < numStudents; i++) {
		if (classRosterArray[i]->GetStudentID() != StudentID) {
			continue;
		} else {
			cout << "Average Days in Course for " << StudentID << ": "; //Don't forget to show your work
			cout << (classRosterArray[i]->GetNumCompletionDays()[0]
				+ classRosterArray[i]->GetNumCompletionDays()[1]
				+ classRosterArray[i]->GetNumCompletionDays()[2]) / 3 << endl;
		}
	}
}
//Checks emails for @ symbol, a "dot", and that there are no spaces, then SPOILER ALERT, prints all invalid emails. 
void Roster::printInvalidEmails() {
	for (int i = 0; i <= (Roster::lastIndex); i++) 
	{
		bool isInValid = false; //still not aliens
		string sEmail = (classRosterArray[i]->GetEmail()); //local variable to hold email string
		
		if (sEmail.find("@") == string::npos || sEmail.find(".") == string::npos || sEmail.find(" ") != string::npos) {
			isInValid = true; //This type of code is why i have kevinsJunkEmail@gmail.com
		}
		if (isInValid == true) {
			cout << "Email not valid: " << sEmail << endl; //prints invald emails
		}
	}
}
//Does what it says on the box
void Roster::printByDegreeProgram(DegreeProgram program) {
	for (int i = 0; i < numStudents; i++) {
		if (classRosterArray[i]->GetProgram() == program)
			classRosterArray[i]->PrintStudent();
	} cout << endl;
}

//Function parses string of student data, breaking it in to attributes and passing it in to add function
void Roster::parseStudents(string studentData) {
	
	int endStudent = studentData.find(","); //find comma **endStudent = end of subString, comma not included**
	string tempID = studentData.substr(0, endStudent); //pull substring before comma
	
	int startStudent = endStudent + 1; //move to next substring
	endStudent = studentData.find(",", startStudent); //pull substring between commas
	string tempfName = studentData.substr(startStudent, endStudent - startStudent); //first name

	startStudent = endStudent + 1; //move to next substring
	endStudent = studentData.find(",", startStudent); //pull substring between commas
	string templName = studentData.substr(startStudent, endStudent - startStudent); //last name

	startStudent = endStudent + 1; //move to next substring
	endStudent = studentData.find(",", startStudent); //pull substring between commas
	string tempEmail = studentData.substr(startStudent, endStudent - startStudent); //email

	startStudent = endStudent + 1; //move to next substring
	endStudent = studentData.find(",", startStudent); //pull substring between commas
	int tempAge = stoi(studentData.substr(startStudent, endStudent - startStudent)); //age

	startStudent = endStudent + 1; //move to next substring
	endStudent = studentData.find(",", startStudent); //pull substring between commas
	int course1 = stoi(studentData.substr(startStudent, endStudent - startStudent)); //Days to completion course 1 and convert to int

	startStudent = endStudent + 1; //move to next substring
	endStudent = studentData.find(",", startStudent); //pull substring between commas
	int course2 = stoi(studentData.substr(startStudent, endStudent - startStudent)); //Days to completion course 2 and convert to int

	startStudent = endStudent + 1; //move to next substring
	endStudent = studentData.find(",", startStudent); //pull substring between commas
	int course3 = stoi(studentData.substr(startStudent, endStudent - startStudent)); //Days to completion course 3 and convert to int

	DegreeProgram tempProgram = SECURITY; //Default Degree Program **and option 1 if Program actual == default**
	startStudent = endStudent + 1; //move to next substring
	endStudent = studentData.find(",", startStudent); //pull substring between commas
	if (studentData.substr(startStudent, endStudent - startStudent) == "SECURITY") {
		tempProgram = SECURITY; //Degree Program option 2
	} else if (studentData.substr(startStudent, endStudent - startStudent) == "NETWORK") {
		tempProgram = NETWORK; //Degree Program option 3
	} else if (studentData.substr(startStudent, endStudent - startStudent) == "SOFTWARE") {
		tempProgram = SOFTWARE;
	}
	add(tempID, tempfName, templName, tempEmail, tempAge, course1, course2, course3, tempProgram); //Create new object
}
	// ***** Releases dynamically allocated memory *****
Roster::~Roster() {
	cout << "DESTRUCTOR CALLED!" << endl << endl;
	for (int i = 0; i < numStudents; i++) {
		cout << "Removing Student #" << i + 1 << endl;
		delete classRosterArray[i];
		classRosterArray[i] = nullptr;
	}
}