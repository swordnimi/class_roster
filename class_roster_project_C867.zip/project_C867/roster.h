#pragma once
#include "student.h"

//Roster Class 
class Roster {
public:
	void add(string sIDRos, string fNameRos, string lNameRos, string emailRos, int ageRos, int days1, int days2, int days3, DegreeProgram degProgramRos);
	void removeStudent(string studentID);
	void printAll();
	void printAverageDaysInCourse(string StudentID);
	void printInvalidEmails();
	void printByDegreeProgram(DegreeProgram program);
	void parseStudents(string row);
	~Roster();
	
	int lastIndex = -1;
	const static int numStudents = 5;
	
	Student* classRosterArray[numStudents];
};