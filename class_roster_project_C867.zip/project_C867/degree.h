#pragma once
#include <string>
using namespace std;
enum DegreeProgram
{
	SECURITY,
	NETWORK,
	SOFTWARE
};
static const std::string programStrings[] = { "SECURITY", "NETWORK", "SOFTWARE" }; //Parrallel array of strings