#pragma once
#include "degree.h"
#include <iostream>
using namespace std;

// ***** Student Class *****
class Student {
private:
	string studentID;
	string firstName;
	string lastName;
	string studentEmail;
	int age;
	int numCompletionDays[3];
	DegreeProgram program;

	const int numDays = 3; //Array size for number of days to completion

public:
	// ***** Mutator Functions *****
	void SetStudentID(string newStudentID);
	void SetFirstName(string newFirstName);
	void SetLastName(string newLastName);
	void SetEmail(string newStudentEmail);
	void SetAge(int newAge);
	void SetNumCompletionDays(int* beginCompletionDays);
	void SetProgram(DegreeProgram newProgram);

	//***** Accessor Functions *****
	string GetStudentID();
	string GetFirstName();
	string GetLastName();
	string GetEmail();
	int GetAge();
	int* GetNumCompletionDays();
	DegreeProgram GetProgram();
	void PrintHeader();
	void PrintStudent();
	Student(string sID, string fName, string lName, string sEmail, int sAge, int* compDays, DegreeProgram degProgram);
};